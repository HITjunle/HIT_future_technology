#include<stdio.h>
int main() {
	printf("%zu ", sizeof(char));
	printf("%zu ", sizeof(short));
	printf("%zu ", sizeof(int));
	printf("%zu ", sizeof(long));
	printf("%zu ", sizeof(long long));
	printf("%zu ", sizeof(float));
	printf("%zu ", sizeof(double));
	printf("%zu ", sizeof(long double));
	printf("%zu ", sizeof(void*));
}
