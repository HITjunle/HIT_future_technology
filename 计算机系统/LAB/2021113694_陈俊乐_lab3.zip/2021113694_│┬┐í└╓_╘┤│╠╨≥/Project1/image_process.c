#include<stdio.h>
#include "time.h"
#include <immintrin.h>
#include <windows.h>
#include <omp.h>

#define width 1080
#define length 1920
#define BLOCK_SIZE 4
long img[length][width],img_process[length][width]; 
void creat_image() {
	for (int i = 0; i < length; i++)
		for (int j = 0; j < width; j++)
			img[i][j] = rand() % 256;
}
void smooth0(long img[length][width]) {
	for (int i = 1; i < length-1; i++)
	{
		for (int j = 1; j < width-1; j++)
		{
			img_process[i][j] = (img[i - 1][j] + img[i + 1][j] + img[i][j - 1] + img[i][j + 1]) / 4;
		}
	}
}

//����λ�������
void smooth1(long img[length][width]) {
	for (int i = 1; i < length - 1; i++)
	{
		for (int j = 1; j < width - 1; j ++)
		{
			img_process[i][j] = (img[i - 1][j] + img[i + 1][j] + img[i][j - 1] + img[i][j + 1]) >> 2;
		}
	}
}
//ѭ��չ��
 void smooth2(long img[length][width]) {
	for (int i = 1; i < length-1; i ++)
	{
		for (int j = 1; j < width-4; j = j+4)
		{
			img_process[i][j] = (img[i - 1][j] + img[i + 1][j]+img[i][j - 1] + img[i][j + 1]) /4;
			img_process[i][j+1] = (img[i - 1][j + 1] + img[i + 1][j + 1] + img[i][j] + img[i][j + 2]) /4;
			img_process[i][j + 2] = (img[i - 1][j + 2] + img[i + 1][j + 2] + img[i][j + 1] + img[i][j + 3]) / 4;
			img_process[i][j + 3] = (img[i - 1][j + 3] + img[i + 1][j + 3] + img[i][j + 2] + img[i][j + 4]) /4;
		}
	}
}

 //����
 void smooth3(long img[length][width]) {
	 __m128i a, b, c, d;
	 __m128i avg = _mm_set1_epi32(4); // ���þ�ֵ������

	 for (int i = 1; i < length - 1; i++)
	 {
		 for (int j = 1; j < width - 1; j += 4) // ÿ�μ���4��long��������
		 {
			 // �������ж�ȡ���ݲ����������
			 a = _mm_loadu_si128((__m128i*) & img[i - 1][j]);
			 b = _mm_loadu_si128((__m128i*) & img[i + 1][j]);
			 c = _mm_loadu_si128((__m128i*) & img[i][j - 1]);
			 d = _mm_loadu_si128((__m128i*) & img[i][j + 1]);
			 // ����ƽ��ֵ
			 __m128i sum = _mm_add_epi32(a, b);
			 sum = _mm_add_epi32(sum, c);
			 sum = _mm_add_epi32(sum, d);
			 sum = _mm_div_epi32(sum, avg);
			 // ������洢��������
			 _mm_storeu_si128((__m128i*) & img_process[i][j], sum);
		 }
	 }
 }
 //�ֿ�
 void smooth4(long img[length][width]) {
	 for (int ii = 1; ii < length - 1; ii += BLOCK_SIZE) {
		 for (int jj = 1; jj < width - 1; jj += BLOCK_SIZE) {
			 for (int i = ii; i <min(ii+BLOCK_SIZE, length-1); i++) {
				 for (int j = jj; j <min(jj+BLOCK_SIZE, width-1); j++) {
					 img_process[i][j] = (img[i - 1][j] + img[i + 1][j] + img[i][j - 1] + img[i][j + 1]) / 4;
				 }
			 }
		 }
	 }
 }
 //�ֿ����λ
 void smooth5(long img[length][width]) {
	 for (int ii = 1; ii < length - 1; ii += BLOCK_SIZE) {
		 for (int jj = 1; jj < width - 1; jj += BLOCK_SIZE) {
			 for (int i = ii; i < ii + BLOCK_SIZE && i < length - 1; i++) {
				 for (int j = jj; j < jj + BLOCK_SIZE && j < width - 1; j++) {
					 img_process[i][j] = (img[i - 1][j] + img[i + 1][j] + img[i][j - 1] + img[i][j + 1]) >> 2;
				 }
			 }
		 }
	 }
 }
 //ѭ��չ������λ
 void smooth6(long img[length][width]) {
	 for (int i = 1; i < length - 1; i++)
	 {
		 for (int j = 1; j < width - 4; j = j + 4)
		 {
			 img_process[i][j] = (img[i - 1][j] + img[i + 1][j] + img[i][j - 1] + img[i][j + 1]) >> 2;
			 img_process[i][j + 1] = (img[i - 1][j + 1] + img[i + 1][j + 1] + img[i][j] + img[i][j + 2]) >> 2;
			 img_process[i][j + 2] = (img[i - 1][j + 2] + img[i + 1][j + 2] + img[i][j + 1] + img[i][j + 3]) >> 2;
			 img_process[i][j + 3] = (img[i - 1][j + 3] + img[i + 1][j + 3] + img[i][j + 2] + img[i][j + 4]) >> 2;
		 }
	 }
 }
int main() {
	clock_t start, end;
	 double duration0;
	 int i = 1000;
	creat_image();// create a random img array
	start = clock();
	while (i != 0)
	{
		smooth0(img);
		i--;
	}
	end = clock();
	duration0 = (double)(end - start) / CLOCKS_PER_SEC;
	printf("��������ʱ��: %f ��\n", duration0);

	return 0;

}